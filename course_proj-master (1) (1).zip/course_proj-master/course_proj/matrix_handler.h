#pragma once
#include<stdio.h>
#include<stdlib.h>
#include<time.h>
#include<Windows.h>

struct Element
{
	int value;

	int rowIndex;

	int colIndex;

	int coordX;

	int coordY;

	int maxPosX;
};

int** createMatrix(size_t size) // init dynamic matrix 
{

	int** matrix = (int**)malloc(size * sizeof(int*) + (size * size) * sizeof(int)); // allocate memory for array of pointers to rows and integer elements in row
	int* start = (int*)((char*)matrix + size * sizeof(int*)); //calculate start address ov matrix 

	for(int i = 0; i < size; ++i)
	{
		matrix[i] = start + i * size;
	}
	  
	return matrix;
}

void fillMatrix (int** matrix, size_t size)
{
	srand(time(NULL));

	int randNum = 0;
	//int x = 0; 

	for (int i = 0; i < size; i++) 
	{
		for (int j = 0; j < size; j++) 
		{
			randNum = rand() % 150 + 1;
			matrix[i][j] = /*x;*/randNum;
			//x++;
		} 
	}

}

struct Element matrixMaxVal(int **matrix, int startPoint, size_t size, HANDLE console, COORD pos)
{
	struct Element element;
	int maxVal = 0;
	
	
	for (int row = 0; row < size; row++)
	{
		for (int col = 0; col < size; col++)
		{
			pos.X += 5;
			SetConsoleCursorPosition(console, pos);

			if (matrix[row][col] > maxVal && (row >= startPoint && col >= startPoint))
			{
				maxVal = matrix[row][col]; 
				element.value = maxVal;
				element.colIndex = col;
				element.rowIndex = row;
				element.maxPosX = pos.X;
			}

			if(row == element.rowIndex &&  col == size - 1)
			{
				element.coordX = pos.X;
				element.coordY = pos.Y;
			}
			
		}
		pos.Y += 3;
		pos.X -= 5 * size;
		SetConsoleCursorPosition(console, pos);
	}



	return element;

}

void clearMemory(void **matrix)
{
	free(matrix);
}

