#include <stdio.h>
#include <time.h>
#include <windows.h>
#include "animation_helper.h"
#include "matrix_handler.h"


#define N 5 // Sets matrix size N x N

int main() 
{
    int** matrix = createMatrix(N);
    int maxvalue;
    int maxrowindex, maxcolindex;

    COORD pos;
    pos.X = 10; 
    pos.Y = 2; 
    int defaultX = pos.X;
    int defaultY = pos.Y;
    int maxPosX; 
    

    HANDLE console = GetStdHandle(STD_OUTPUT_HANDLE);

    fillMatrix(matrix, N);

    struct MatrixInfo info = {.boundCoordY = (N * 3) - 1, .boundCoordX = (N * 5) + 12};
    
    printMatrix(matrix, N, console, pos);

    delay(0.6); //delay for initialization 

    for (int startPoint = 0; startPoint < N; startPoint++)
    {

        pos.X = defaultX;
        pos.Y = defaultY;
        SetConsoleCursorPosition(console, pos);

        struct Element element = matrixMaxVal(matrix, startPoint, N, console, pos);
        maxPosX = element.maxPosX;

        if(element.coordX > info.boundCoordX || element.coordY > info.boundCoordY)
        {
            system("cls");
            printf("cursor was out of matrix bounds: cursor coords { x - %d, y - %d}", element.coordX, element.coordY);

            delay(3);
            exit(-1);
        }
        else
        {
            pos.Y = element.coordY;
            pos.X = element.coordX;
            SetConsoleCursorPosition(console, pos);
        }

        if(element.colIndex == element.rowIndex && (element.rowIndex == startPoint - 1 || element.rowIndex == startPoint))
        {
            continue;
        }

        for (int i = element.rowIndex; i > startPoint; i--)
        {
            for (int j = N - 1; j >= startPoint; j--)
            {
                int temp = matrix[i][j];
                matrix[i][j] = matrix[i - 1][j];
                matrix[i -1][j] = temp;

                swapRow(temp, matrix[i][j], console, pos);
                
                if (temp == element.value)
                {
                    maxPosX = pos.X; 
                }

                 pos.X -= 5;
                SetConsoleCursorPosition(console, pos);
            }
            pos.X += (N - startPoint) * 5;
            pos.Y -= 3;
            SetConsoleCursorPosition(console, pos);
        }
       
        pos.Y = info.boundCoordY;
        pos.X = maxPosX;
        SetConsoleCursorPosition(console, pos);

        for (int j = element.colIndex; j > startPoint; j--)
        {
            for (int i = N - 1; i >= startPoint; i--)
            {
                int temp = matrix[i][j];
                matrix[i][j] = matrix[i][j - 1];
                matrix[i][j - 1] = temp;
                swapCol(temp, matrix[i][j], console, pos);
                pos.Y -= 3;
                SetConsoleCursorPosition(console, pos);
            }
            pos.X -= 5;
            pos.Y += (N - startPoint) * 3;
            SetConsoleCursorPosition(console, pos);
        }
    }

    delay(10);
    clearMemory(matrix); 

    return 0;
}

