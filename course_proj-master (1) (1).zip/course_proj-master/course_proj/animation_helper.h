#pragma once
#include<time.h>
#include<windows.h>


struct MatrixInfo
{
    int boundCoordX;
    int boundCoordY;
};

void delay(float number_of_seconds)
{
    float milli_seconds = 1000 * number_of_seconds;

    clock_t start_time = clock();

    while (clock() < start_time + milli_seconds);
}

void clearTrace(int numDig)
{
    for (int j = 0; j < numDig; j++)
    {
        printf(" ");
    }
}

void printMatrix(int **arr, int size, HANDLE console, COORD pos)
{
    delay(1.5);
    system("cls");
    for (int i = 0; i < size ; i++)
    {
        for (int j = 0; j < size; j++)
        {
            pos.X += 5;
            SetConsoleCursorPosition(console, pos);
            printf("%d ", arr[i][j]);
        }
        pos.Y += 3;
        pos.X -= 5 * size;
        SetConsoleCursorPosition(console, pos);
    }

}
void swapRow(int fstVal, int secVal, HANDLE console, COORD pos)
{
    int num1 = fstVal ? fstVal: 1 ;
    int num2 = secVal ? secVal: 1 ;
     int fstNumDigits = 0;
    int secNumDigits = 0;

    while (num1 != 0 || num2 != 0) 
    {
        if (num1 != 0) {
            int fstDigits = num1 % 10;
            fstNumDigits++;
            num1 /= 10;
        }

        if (num2 != 0) {
            int secDigits = num2 % 10;
            secNumDigits++;
            num2 /= 10;
        }
    }

    for (int i = 0; i < 3; i++)
    { 

        clearTrace(fstNumDigits);

        pos.Y--;

        SetConsoleCursorPosition(console, pos);

        if (i == 2 && secNumDigits > fstNumDigits)
        {
            clearTrace(secNumDigits);

        }

        SetConsoleCursorPosition(console, pos);

        printf("%d", fstVal);
        delay(0.1);

        if (i == 2 && secNumDigits > fstNumDigits)
        {
            clearTrace(secNumDigits);

        }
        SetConsoleCursorPosition(console, pos);
    }

    for (int i = 0; i < 3; i++)
    {
        if (i != 0) {
            clearTrace(secNumDigits);
        }

        pos.Y++;
        
        SetConsoleCursorPosition(console, pos);
        
        printf("%d", secVal);
        delay(0.1);
        SetConsoleCursorPosition(console, pos);
    }
}

void swapCol(int fstVal, int secVal, HANDLE console, COORD pos)
{

    int num1 = fstVal ? fstVal : 1;
    int num2 = secVal ? secVal : 1;
    int fstNumDigits = 0;
    int secNumDigits = 0;

    while (num1 != 0 || num2 != 0)
    {
        if (num1 != 0) {
            int fstDigits = num1 % 10;
            fstNumDigits++;
            num1 /= 10;
        }

        if (num2 != 0) {
            int secDigits = num2 % 10;
            secNumDigits++;
            num2 /= 10;
        }
    }

    int delta = fstNumDigits == 3  ?  0 :  1 ;

    if (fstNumDigits == secNumDigits && (fstNumDigits == 1))
    {
        delta = 2;
    }

    clearTrace(fstNumDigits);
    SetConsoleCursorPosition(console, pos);

    pos.Y--;
    SetConsoleCursorPosition(console, pos);

    printf("%d", fstVal);
    delay(0.3);
    SetConsoleCursorPosition(console, pos);

    clearTrace(fstNumDigits);

    pos.X -= 5;
    SetConsoleCursorPosition(console, pos);

    printf("%d", fstVal);
    delay(0.3);

    pos.Y++;
    SetConsoleCursorPosition(console, pos);

    clearTrace(secNumDigits);
    pos.X += 5;
    SetConsoleCursorPosition(console, pos);
    printf("%d", secVal);
    delay(0.3);

    pos.X -= 5;
    pos.Y--;
    SetConsoleCursorPosition(console, pos);

    clearTrace(fstNumDigits);

    pos.Y++;

    SetConsoleCursorPosition(console, pos);
    printf("%d", fstVal);
    delay(0.3);
}



